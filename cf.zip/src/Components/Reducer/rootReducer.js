import { combineReducers } from 'redux'
import reducer from '../Reducer/reducer'


const rootReducer = combineReducers({reducer})
export default rootReducer